# Azure Bot

This is an experimental extension that integrates Azure related bots with Visual Studio Code.

This version provides experimental **Azure IoT Hub Bot** 

Press **Alt + B** to initialize, then select bot.


![feature X](screenshot.png)

## Known Issues

Nothing yet...

## Release Notes

### 0.0.1

Initial release
